module.exports = {
  name: "mesaj-engel",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla veya sıfırla ile belirtmelisin]
  $onlyIf[$message!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  Mesaj engel kanalı <#$mentionedChannels[1]> olarak ayarlandı
  $setServerVar[msje;$mentionedChannels[1]]
  $onlyIf[$mentionedChannels[1]!=;Bir kanal etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Mesaj engel sıfırlandı
  $setServerVar[msje;]
  $onlyIf[$getServerVar[msje]!=;Zaten ayarlanmamış]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  `
}