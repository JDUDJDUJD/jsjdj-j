module.exports = {
   name: "rozet",
   code:`
$if[$message!=$mentioned[1]]
$title[Kişinin Rozetleri]
$description[$replaceText[$getGlobalUserVar[yardımcı;$mentioned[1]];evt;👔] $replaceText[$getGlobalUserVar[gururlu;$mentioned[1]];evt;🎎]]
$color[RANDOM]
$onlyIf[$getGlobalUserVar[rsayı;$mentioned[1]]!=0;{title:Kişide rozet bulunmamakta} {color:RANDOM}]
$else
$title[Rozetlerin]
$description[$replaceText[$getGlobalUserVar[yardımcı;$authorID];evt;👔] $replaceText[$getGlobalUserVar[gururlu;$authorID];evt;🎎]]
$color[RANDOM]
$onlyIf[$getGlobalUserVar[rsayı;$authorID]!=0;{title:Rozetin Bulunmamakta} {color:RANDOM}]
$endif
`
}
