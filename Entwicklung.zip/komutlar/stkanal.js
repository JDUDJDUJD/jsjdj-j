module.exports = {
  name: "sayı-tahmin",
  code:`
  $onlyIf[$checkContains[$messagd[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirltmelisin]
  $onlyIf[$message!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  $setServerVar[stsayı;$random[1;500]]
  $channelSendMessage[$mentionedChannels[1];Sayı tahmin kanalı bu kanal olarak ayarlandı tahmin ediceğin sayı 1 ile 500 arasındadır]
  Sayı tahmin kanalı <#$mentionedChannels[1]> olarak ayarlandı
  $setServerVar[stkanal;$mentionedChannels[1]]
  $onlyIf[$mentionedChannels[1]!=;Bir kanal etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Sayı tahmin sıfırlandı
  $setServerVar[stkanal;]
  $setServerVar[stsayı;]
  $onlyIf[$getServerVar[stkanal]!=;Zaten ayarlanmamış]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  `
}