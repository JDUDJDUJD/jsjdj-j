module.exports = ({
  name: "suçlu",
  code:`
  $if[$message[1]!=$mentioned[1]]
  $image[https://api.cool-img-api.ml/wanted?image=$userAvatar[$mentioned[1]]]
  $else
$image[https://api.cool-img-api.ml/wanted?image=$userAvatar[$authorID]]
$endif
$color[RANDOM]
  `
})