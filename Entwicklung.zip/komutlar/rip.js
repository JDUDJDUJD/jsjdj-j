module.exports = ({
  name: "rip",
  code:`
  $if[$message[1]!=$mentioned[1]]
  $image[https://api.cool-img-api.ml/rip?image=$userAvatar[$mentioned[1]]]
  $else
  $image[https://api.cool-img-api.ml/rip?image=$userAvatar[$authorID]]
  $endif
  $color[RANDOM]
  `
})