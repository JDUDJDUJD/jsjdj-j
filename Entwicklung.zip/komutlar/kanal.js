module.exports = {
   name: "kanal",
   code:`
Kanal başarıyla $replaceText[$replaceText[$message;aç;açıldı];kilitle;kilitlendi]
$modifyChannelPerms[$channelID;$replaceText[$replaceText[$message;aç;+];kilitle;-]sendmessages;$roleID[@everyone]]
$onlyIf[$checkContains[$message;aç;kilitle]==true;Doğru kullanım !kanal kilitle/aç]
$onlyIf[$message!=;Doğru kullanım !kanal kilitle/aç]
$onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
$onlyBotPerms[admin;Botun **Yönetici** yetkisi yok]
`
}
