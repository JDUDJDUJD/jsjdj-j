module.exports = {
  name: "unmute",
  code:`
$if[$getServerVar[mlog]==]
$thumbnail[$userAvatar[$mentioned[1]]]
$title[$nickname[$mentioned[1]] kişisinin mutesi kaldırıldı]
$takeRole[$mentioned[1];$getServerVar[mrol]]
$else
$channelSendMessage[$getServerVar[mlog];
{title:Bir Kullanıcının Mutesi Kalktı}
{description:
Mutesi Alınan : <@$mentioned[1]>
Muteyi Kaldıran <@$authorID>
}
{color:RANDOM} {thumbnail:$userAvatar[$mentioned[1]]}]
$thumbnail[$userAvatar[$mentioned[1]]]
$title[$nickname[$mentioned[1]] kişisinin mutesi kalktı]
$takeRole[$mentioned[1];$getServerVar[mrol]]
$endif
$onlyIf[$hasRole[$mentioned[1];$getServerVar[mrol]]!=falsr;Kullanıcı zaten mutesiz]
$onlyIf[$mentioned[1]!=$clientID,;Kendini etiketleyemezsin]
$onlyIf[$mentioned[1]!=$authorID;Kendini muteni kaldıramazsın]

$argsCheck[>1;Birini etiketlemelisin]
$onlyBotPerms[admin;Botun **Yönetici** yetkisi bulunmamakta]
$onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
$onlyIf[$getServerVar[mrol]!=;]
$suppressErrors[Kullanıcı mutesi alınamıyor]
$color[RANDOM]
  `
}