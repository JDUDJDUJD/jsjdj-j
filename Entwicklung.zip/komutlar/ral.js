module.exports = {
   name: "rozet-al",
   code:`
$onlyIf[$checkContains[$noMentionMessage;yardımcı;gururlu]==true;Yardımcı veya gururlu rozetleri bulunmakta]
$onlyIf[$noMentionMessage!=;Yardımcı ve ya gururlu yazmalısın]
$if[$noMentionMessage==gururlu]
Gururlu rozeti kişiden alındı
$setGlobalUserVar[gururlu;]
$setGlobalUserVar[rsayı;$sub[$getGlobalUserVar[rsayı;$mentioned[1]];1];$mentioned[1]]
$onlyIf[$getGlobalUserVar[gururlu;$mentioned[1]]!=;Zaten kişide rozet bulunmamakta]
$endif
$if[$noMentionMessage==yardımcı]
Yardımcı rozeti kişiden alındı
$setGlobalUserVar[yardımcı;]
$setGlobalUserVar[rsayı;$sub[$getGlobalUserVar[rsayı;$mentioned[1]];1];$mentioned[1]]
$onlyIf[$getGlobalUserVar[yardımcı;$mentioned[1]]!=;Kişide zaten rozet yok]
$endif
$argsCheck[>1;Birini etiketlemelisin]
$onlyForIDs[$botOwnerID;Bu komutu sadece sahibim kullanabilir]
`
}
