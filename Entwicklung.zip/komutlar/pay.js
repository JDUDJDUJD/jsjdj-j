module.exports = {
  name: "pay",
  code:`
  $setGlobalUserVar[para;$sub[$getGlobalUserVar[para;$authorID];$noMentionMessage];$authorID]
  $setGlobalUserVar[para;$sum[$getGlobalUserVar[para;$mentioned[1]];$noMentionMessage];$mentioned[1]]
  $title[\`$username[$mentioned[1]]\` Kişisine \`$noMentionMessage\` Para Yollandı]
  $color[RANDOM]
  $onlyIf[$isBot[$mentioned[1]]!=true;Bir bota para atamazsın]
  $onlyIf[$isNumber[$noMentionMessage]==true;Girdiğin miktar bir sayı değil]
  $onlyIf[$authorID!=$mentioned[1];Kendine para atamazsın]
  $onlyIf[$getGlobalUserVar[para;$authorID]>=$noMentionMessage;Paran yeterli değil]
  $onlyIf[$noMentionMessage>=1;0 dan küçük bir miktar yazamazsın]
  $onlyIf[$noMentionMessage!=;Bir miktar yazmalısın]
  $argsCheck[>1;Birini etiketlemelisin]
  `
}