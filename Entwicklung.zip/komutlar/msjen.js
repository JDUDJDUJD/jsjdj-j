module.exports = {
  name: "$alwaysExecute",
  code:`
  $deletecommand
  $onlyIf[$hasPerms[$authorID;admin]!=true;]
  $onlyForChannels[$getServerVar[msje];]
  $onlyIf[$getServerVar[msje]!=;]
  `
}