module.exports = {
  name: "$alwaysExecute",
  code:`$suppressErrors[Bot reaksiyon ekleyemiyor lütfen rollerimi düzenle]
  $setServerVar[ssayı;$sum[$getServerVar[ssayı];1]]
  $addCmdReactions[✔]
  $onlyIf[$checkContains[$message;$sum[$getServerVar[ssayı];1]]==true;Hey önceki yazılan sayı $getServerVar[ssayı] bir sonraki sayıyı yazmalısın]
  $onlyIf[$isNumber[$message]!=false;Girdiğin yazı bir sayı olmalı]
  $onlyForChannels[$getServerVar[skanal];]
  $onlyIf[$getServerVar[skanal]!=;]
  $onlyIf[$isBot[$authorID]==false;]

 
  `
}