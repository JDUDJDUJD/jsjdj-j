module.exports = {
  name: "mute-rol",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve sıfırla ile belirtmelisin]
  $onlyIf[$message[1]!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  Mute rol <@&$mentionedRoles[1]> olarak belirlendi
  $setServerVar[mrol;$mentionedRoles[1]]
  $onlyIf[$mentionedRoles[1]!=;Bir rol etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Mute rol sıfırlandı
  $setServerVar[mrol;]
  $onlyIf[$getServerVar[mrol]!=;Zaten ayarlanmamış]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  `
}