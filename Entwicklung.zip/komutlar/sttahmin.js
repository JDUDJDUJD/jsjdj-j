module.exports = {
  name: "$alwaysExecute",
  code:`
  $if[$message==$getServerVar[stsayı]]
  $setServerVar[stsayı;$random[1;500]]
  $channelSendMessage[$channelID;Yeni bir sayı tutuldu]
  Doğru sayıyı buldun $username 
  $else
  $addCmdReactions[❌]
  $endif
  $onlyIf[$message<=500;Sayı 500 den büyük olamaz]
  $onlyIf[$message>=1;Sayı 1 den küçük olamaz]
  $onlyIf[$isNumber[$message]!=false;Girilen yazı bir sayı değil]
  $onlyForChannels[$getServerVar[stkanal];]
  $onlyIf[$getServerVar[stkanal]!=;]
  $onlyIf[$isBot[$authorID]==false;]
  `
}