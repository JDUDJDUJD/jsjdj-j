module.exports = {
  name: "mute",
  code:`
$if[$getServerVar[mlog]==]
$thumbnail[$userAvatar[$mentioned[1]]]
$title[$nickname[$mentioned[1]] $noMentionMessage sebebiyle mutelendi]
$giveRole[$mentioned[1];$getServerVar[mrol]]
$else
$channelSendMessage[$getServerVar[mlog];
{title:Bir Kullanıcı Mutelendi}
{description:
Mutelenen : <@$mentioned[1]>
Muteleyen: <@$authorID>
Sebep : $noMentionMessage
}
{color:RANDOM} {thumbnail:$userAvatar[$mentioned[1]]}]
$thumbnail[$userAvatar[$mentioned[1]]]
$title[$nickname[$mentioned[1]] $noMentionMessage sebebiyle mutelendi]
$giveRole[$mentioned[1];$getServerVar[mrol]]
$endif
$onlyIf[$hasRole[$mentioned[1];$getServerVar[mrol]]!=true;Kullanıcı zaten muteli]
$onlyIf[$mentioned[1]!=$clientID,;Kendini etiketleyemezsin]
$onlyIf[$mentioned[1]!=$authorID;Kendini muteleyemezsin]
$onlyIf[$hasPerms[$mentioned[1];admin]!=true;Yetkili birini muteleyemezsin]
$onlyIf[$noMentionMessage!=;Bir sebep belirtmelisin]
$argsCheck[>1;Birini etiketlemelisin]
$onlyBotPerms[admin;Botun **Yönetici** yetkisi bulunmamakta]
$onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
$onlyIf[$getServerVar[mrol]!=;]
$suppressErrors[Kullanıcı mutelenemiyor]
$color[RANDOM]
  `
}