module.exports = {
  name: "rozet-ver",
  code:`
  $onlyIf[$checkContains[$noMentionMessage;yardımcı;gururlu]==true;Sadece yardımcı ve gururlu rozetleri bulunmakta]
  $onlyIf[$noMentionMessage!=;Yardımcı ve ya gururlu yazmalısın]
  $if[$noMentionMessage==yardımcı]
  Yardımcı rozeti verildi
  $setGlobalUserVar[yardımcı;evt;$mentioned[1]]
$setGlobalUserVar[rsayı;$sum[$getGlobalUserVar[rsayı;$mentioned[1]];1];$mentioned[1]]
  $onlyIf[$getGlobalUserVar[yardımcı;$mentioned[1]]!=evt;Zaten rozeti bulunmakta]
  $endif
  $if[$noMentionMessage==gururlu]
  Gururlu rozeti verildi
  $setGlobalUserVar[gururlu;evt;$mentioned[1]]
  $setGlobalUserVar[rsayı;$sum[$getGlobalUserVar[rsayı;$mentioned[1]];1];$mentioned[1]]
  $onlyIf[$getGlobalUserVar[gururlu;$mentioned[1]]!=evt;Zaten rozeti bulunmakta]
  $endif
  $argsCheck[>1;Birini etiketlemelisin]
  $onlyForIDs[$botOwnerID;Bu komutu sadece sahibim kullanabilir]
  `
}