module.exports = {
  name: "sayı-saymaca",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirtmelisin]
  $onlyIf[$message!=;Ayarla ve ya sıfırla ile belirtmelisin]
  $if[$message[1]==ayarla]
  Sayı saymaca kanal <#$mentionedChannels[1]> 
  $setServerVar[skanal;$mentionedChannels[1]]
  $onlyIf[$mentionedChannels[1]!=;Bir kanal etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Sayı saymaca kanalı sıfırlandı
  $setServerVar[skanal;]
  $setServerVar[ssayı;0]
  $onlyIf[$getServerVar[skanal]!=;Zaten ayarlanamış]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  `
}