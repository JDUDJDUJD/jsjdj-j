module.exports = ({
   name: "i",
   aliases: ["istatistik"],
   code:`
İstatistikler yükleniyor...
$editIn[5s;
{title:İstatistikler} {description:
Bot Sahibi $username[$botOwnerID] | <@$botOwnerID>

Bot Kuruluş Zamanı $creationDate[$clientID]

Kullanılan Paket:Aoi.js
Aoi.js Sürümü:$packageVersion
Node.js Sürümü:$nodeVersion
Uptime Süresi:$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$uptime;s; Saniye;-1];m; Dakika;-1];h; Saat;-1];d; Gün;-1];w; Hafta;-1]
Kullanılan cpu:$cpu
Kalan cpu:$sub[100;$cpu]
Kullanılan ram:$ram
Kalan ram:$sub[$maxRam;$ram]
Shard:$replaceText[$shardID;0;Shard Bulunmamakta]

Toplam Sunucu:$serverCount
Toplam Kullanıcı:$allMembersCount
Toplam Metin Kanalı:$allChannelsCount[text]
Toplam Ses Kanalı:$allChannelsCount[voice]
Toplam Komut Sayısı:$commandsCount
Toplam Emoji Sayısı:$emojiCount
} {color:RANDOM}]`
})
