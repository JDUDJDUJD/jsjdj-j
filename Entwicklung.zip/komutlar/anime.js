module.exports = {
  name: "anime",
  code:`
  $image[$randomText[https://media.giphy.com/media/mf4qECoTz8ZVK/giphy.gif;https://media.giphy.com/media/jt7bAtEijhurm/giphy.gif;https://media.giphy.com/media/bqSkJ4IwNcoZG/giphy.gif;https://media.giphy.com/media/Id0IZ49MNMzKHI9qpV/giphy.gif;https://media.giphy.com/media/862A6X2sooSsw/giphy.gif]]
  $cooldown[10s;Bu komutu %time% sonra kullanabilirsin]
  $color[RANDOM]
  `
}