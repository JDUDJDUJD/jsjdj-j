const Aoijs = require("Aoijs")
var fs = require('fs');
const bot = new Aoijs.Bot({
    token: process.env.TOKEN,
  prefix: ["."],
  mobile: false,
  fetchInvites: true
})
bot.onGuildJoin()
bot.onPresenceUpdate()
bot.onBanAdd()
bot.onBanRemove()
bot.onMessageDelete()
bot.onMessageUpdate()
bot.onLeave()
bot.onJoined()
bot.onInviteCreate()
bot.onInviteDelete()
bot.onChannelCreate()
bot.onChannelDelete()
bot.onChannelUpdate()
bot.onRoleCreate()
bot.onRoleDelete()
bot.onRoleUpdate()
bot.onMessage()
var reader = fs.readdirSync("./komutlar").filter(file => file.endsWith(".js"))
for (const file of reader) {
  const command = require(`./komutlar/${file}`)
const keep_alive = require('./http.js')
  bot.command({
    name: command.name,
    aliases: command.aliases,
    bkz: command.bkz,
    code: command.code,
    nonPrefixed: command.nonPrefixed
  });
}
//komutları alta yazın




bot.readyCommand({
  channel: "871682679668621333",
  code:`
$title[Aktifleştim]
$thumbnail[$userAvatar[$clientID]]
$description[
Toplam hizmet ettiğim sunucu sayısı : $serverCount
Toplam hizmet ettiğim kişi sayısı : $allMembersCount
Discord Pingi : $ping
Bot Pingi : Yok
Database Pingi : $dbPing
Hata : Discord'la Bağlantı Sorunu
]
$color[#ffffff]
  `
})

bot.command({
  name: "davet",
  code:`
  $title[Davet Linki]
  $description[
  [Yetkili](https://discord.com/oauth2/authorize?client_id=860561281072103464&scope=bot&permissions=8) [Yetkisiz](https://discord.com/oauth2/authorize?client_id=860561281072103464&scope=bot&permissions=0)
  ]
  $color[#ffffff]
  `
})




bot.command({
  name: "profil",
  code:`
  $if[$message!=$mentioned[1]]
  $thumbnail[$userAvatar[$mentioned[1]]]
  $title[$username[$mentioned[1]]'in Profili]
  $description[
Discord Kimliği = $mentioned[1] | <@$mentioned[1]> | $username[$mentioned[1]]
Etiketi = $discriminator[$mentioned[1]]
Hesap Kuruluş Tarihi = $replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$creationDate[$mentioned[1];time]; years; Yıl;-1]; year; Yıl;-1];months;Ay;-1];month;Ay;-1];weeks;Hafta;-1];week;Hafta;-1];days;Gün;-1];day;Gün;-1];hours;Saat;-1];hour;Saat;-1];minutes; Dakika;-1];minute; Dakika;-1];and; ve;-1];seconds; Saniye;-1];second; Saniye;-1]

Sunucuya Giriş Tarihi =$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$memberJoinedDate[$mentioned[1];time]; years; Yıl;-1]; year; Yıl;-1];months;Ay;-1];month;Ay;-1];weeks;Hafta;-1];week;Hafta;-1];days;Gün;-1];day;Gün;-1];hours;Saat;-1];hour;Saat;-1];minutes; Dakika;-1];minute; Dakika;-1];and; ve;-1];seconds; Saniye;-1];second; Saniye;-1]

Botmu = $replaceText[$replaceText[$isBot[$mentioned[1]];true;Robot];false;İnsan]

Yönetici mi? = $replaceText[$replaceText[$hasPerms[$mentioned[1];admin];false;Yönetici Değil];true;Yönetici]

Dmsi Açık mı? = $replaceText[$replaceText[$isUserDmEnabled[$mentioned[1]];true;Açık];false;Kapalı]
  ]
  $else
$thumbnail[$userAvatar[$authorID]]
  $title[$username'in Profili]
  $description[
Discord Kimliği = $authorID | <@$authorID> | $username[$authorID]
Etiketi = $discriminator[$authorID]
Hesap Kuruluş Tarihi = $replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$creationDate[$authorID;time]; years; Yıl;-1]; year; Yıl;-1];months;Ay;-1];month;Ay;-1];weeks;Hafta;-1];week;Hafta;-1];days;Gün;-1];day;Gün;-1];hours;Saat;-1];hour;Saat;-1];minutes; Dakika;-1];minute; Dakika;-1];and; ve;-1];seconds; Saniye;-1];second; Saniye;-1]

Sunucuya Giriş Tarihi = $replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$memberJoinedDate[$authorID;time]; years; Yıl;-1]; year; Yıl;-1];months;Ay;-1];month;Ay;-1];weeks;Hafta;-1];week;Hafta;-1];days;Gün;-1];day;Gün;-1];hours;Saat;-1];hour;Saat;-1];minutes; Dakika;-1];minute; Dakika;-1];and; ve;-1];seconds; Saniye;-1];second; Saniye;-1]

Botmu = $replaceText[$replaceText[$isBot[$authorID];true;Robot];false;İnsan]

Yönetici mi? = $replaceText[$replaceText[$hasPerms[$authorID;admin];false;Yönetici Değil];true;Yönetici]

Dmsi Açık mı? = $replaceText[$replaceText[$isUserDmEnabled[$authorID];true;Açık];false;Kapalı]
  ]
  $endif
  $color[#ffffff]
  `
})

bot.command({
   name: "avatar",
   code:`
$if[$message[1]!=$mentioned[1]]
$image[$userAvatar[$mentioned[1]]
$else
$image[$userAvatar[$mentioned[1]]
$endif
$color[#ffffff]
`
})

bot.command({
  name: "sayaç",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirtmelisin]
  $onlyIf[$message[1]!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  Sayaç ayarlandı biri katılınca veya ayrılınca <#$mentionedChannels[1]> kanalına bilgilendireceğim
  $setServerVar[sayaçl;$mentionedChannels[1]]
  $onlyIf[$mentionedChannels[1]!=;Bir kanal etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Sayaç sıfırlandı
  $setServerVar[sayaçl;]
  $onlyIf[$getServerVar[sayaçl]!=;Sayaç zaten ayarlanmamış]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yöneti** yetkisine sahip kişiler kullanabilir]
  `
})


bot.command({
  name: "eval",
  code:`
  $eval[$message]
  $onlyForIDs[$botOwnerID;805380946735661066;Bu komutu sadece sahibim kullanabilir]
  `
})

bot.updateCommand({
  channel: "$getServerVar[mesajlog]",
  code:`
$title[Bir Mesaj Düzenlendi]
$description[
Eski Mesaj \`$oldMessage\`

Yeni Mesaj \`$message\`

Düzenlendiği Kanal \`<#$channelUsed>\`

Düzenleneyen Kişi \<@$authorID> | $username | $authorID\`
]
$color[#ffffff]
$onlyIf[$isBot[$authorID]!=true;]
  `
})

bot.deletedCommand({
  channel: "$getServerVar[mesajlog]",
  code:`
$title[Bir Mesaj Silindi]
$description[
Silinen Mesaj  \`$message\`

Silindiği Kanal  \`<#$channelUsed>\`

Silen Kişi  \`<@$authorID> | $username | $authorID\`
]
$color[RANDOM]
$onlyIf[$isBot[$authorID]!=true;]
`
})

bot.command({
  name:"p",
  aliases:['play'],
 code:`$suppressErrors[Şarkı çalmazken kullanamazsın]
 $author[Müzik çalınmaya başlandı;$authorAvatar]
$description[
<a:Emoji_2:861590813791223808>Aranan kelime \`$message\`
<a:Emoji_2:861590813791223808>Bulunan Şarkı : $get[şarkı]
<a:Emoji_2:861590813791223808>Şarkı uzunluğu : $replaceText[$replaceText[$songInfo[duration];Seconds;Saniye;-1];Second;Saniye;-1]
<a:Emoji_2:861590813791223808>Çalan kişi : $userTag[$authorID]]
$color[303136]
$setServerVar[şarkı;$authorID]
$let[şarkı;$playSong[$message;...;yes;yes;:x: \`$message\` adında bir müzik bulamadım.]]
$onlyIf[$voiceID!=;Bir ses kanalına girmezsen kullanamazsın]
$argsCheck[>1;Lütfen bir şarkı adı gir]`
})

bot.command({
  name:"sıralama",
  aliases:['queue'],
 code:`$author[Sıradaki Şarkılar]
 $description[
<a:Emoji_2:861590813791223808>$queue[1;10;{number} - {title}]]
 $color[303136]
 $onlyIf[$voiceID[$clientID]!=;Şarkı çalmazken kullanamazsın]
 $onlyIf[$voiceID!=;Bir ses kanalına girmezsen kullanamazsın]
 $onlyIf[$queue[1;10;{number} - {title}]!=;Sırada bir şarkı bulunmuyor]
 $suppressErrors[Şarkı çalmazken kullanamazsın]`
})

bot.command({
  name:"stop",
  aliases:['stop','pause'],
 code:`
$addCmdReactions[⏸]
$pauseSong
$onlyIf[$voiceID[$clientID]!=;Şarkı çalmazken kullanamazsın]
$onlyIf[$voiceID!=;Bir ses kanalına girmezsen kullanamazsın]
$suppressErrors[Şarkı çalmazken kullanamazsın]
$onlyForIDs[$getServerVar[şarkı];Bu komutu sadece şarkıyı başlatan $userTag[$getServerVar[şarkı]] kullanıcısı kullanabilir]`
})

bot.command({
  name:"restart",
  aliases:['loop'],
 code:`
$addCmdReactions[🔁]
$let[geç;$skipSong]
$let[şarkı;$playSong[$songInfo[title];...;yes;yes;:x: \`$songInfo[title]\` adında bir müzik bulamadım.]]
$onlyIf[$voiceID[$clientID]!=;Şarkı çalmazken kullanamazsın]
$onlyIf[$voiceID!=;Bir ses kanalına girmezsen kullanamazsın]
$suppressErrors[Şarkı çalmazken kullanamazsın]
$onlyForIDs[$getServerVar[şarkı];Bu komutu sadece şarkıyı başlatan $userTag[$getServerVar[şarkı]] kullanıcısı kullanabilir]`
})

bot.command({
  name:"ses",
  aliases:['sound'],
 code:`
$addCmdReactions[🔊]
$volume[$message]
$onlyIf[$voiceID[$clientID]!=;Şarkı çalmazken kullanamazsın]
$onlyIf[$voiceID!=;Bir ses kanalına girmezsen kullanamazsın]
$suppressErrors[Şarkı çalmazken kullanamazsın]
$onlyIf[$message<=100;Maximum 100 olarak ayarlanabilir]
$onlyIf[$isNumber[$message]!=false;Bir sayı girmelisin]
$argsCheck[1;Lütfen bir ses seviyesi gir]
$onlyForIDs[$getServerVar[şarkı];Bu komutu sadece şarkıyı başlatan $userTag[$getServerVar[şarkı]] kullanıcısı kullanabilir]`
})

bot.musicStartCommand({
channel:"$channelID",
code:``
})

bot.musicEndCommand({
channel:"$channelID",
code:``
})


bot.command({
  name:"resume",
  aliases:['resume'],
 code:`
$addCmdReactions[▶]
$resumeSong
$onlyIf[$voiceID[$clientID]!=;Şarkı çalmazken kullanamazsın]
$onlyIf[$voiceID!=;Bir ses kanalına girmezsen kullanamazsın]
$suppressErrors[Şarkı çalmazken kullanamazsın]
$onlyForIDs[$getServerVar[şarkı];Bu komutu sadece şarkıyı başlatan $userTag[$getServerVar[şarkı]] kullanıcısı kullanabilir]`
})

bot.command({
  name: "link-engel",
  code:`
  $onlyIf[$checkContains[$message[1];aç;kapat
  ]==true;Aç ve ya kapat ile belirtmelisin]
  $onlyIf[$message!=;Aç ve ya kapat yazmalısın]
  $if[$message[1]==aç]
  Link engel açıldı
  $setServerVar[lengel;açık]
  $onlyIf[$getServerVar[lengel]!=açık;Link engel zaten açık]
  $endif
  $if[$message[1]==kapat]
  Link engel kapatıldı
  $setServerVar[lengel;kapalı]
  $onlyIf[$getServerVar[lengel]!=kapalı;Link engel zaten kapalı]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  `
})

bot.command({
   name: "ban",
   code:`
$title[Bir Kullanıcı Banlandı]
$thumbnail[$userAvatar[$mentioned[1]]
$description[
Banlanan Kullanıcı : $username[$mentioned[1]]
Banlayan Kişi : $username
Sebep : $replaceText[$noMentionMessage;;Belirtilmemiş]
]
$ban[$mentioned[1];$noMentionedMessage]
$color[#ffffff]
$onlyIf[$mentioned[1]!=$authorID;Kendini banlayamazsın]
$onlyBotPerms[ban;Botun **Banlama** yetkisi bulunmamakta]
$onlyPerms[ban;Bu komutu sadece **Banlama** yetkisine sahip kişiler kullanabilir]
$suppressErrors[Kullanıcı banlanamıyor]
$argsCheck[>1;Birini etiketlemelisin]
`
})

bot.command({
   name: "sil",
   code:`
$title[Mesaj Silme İşlemi Tamamlandı]
$description[
Mesajları silen kişi : $username
Girilen miktar : $message[1]]
$color[RANDOM]
$deleteIn[5s]
$deletecommand
$clear[$message[1]]
$suppressErrors[14 günden önceki mesajları silmeme discord api izin vermiyor]
$onlyIf[$message[1]<=101;100 den fazla mesajı silemem]
$onlyIf[$message[1]>=1;1 den küçük mesaj silemem]
$onlyIf[$isNumber[$message[1]]!=false;Girilen yazı bir sayı değil]
$onlyIf[$message!=;Bir miktar girmelisin]
$onlyPerms[managemessages;Mesaj silme yetkin yok]
$onlyBotPerms[managemessages;Mesaj silme yetkim yok]`
})

bot.command({
   name: "unban",
   code:`
$unban[$message[1]]
$title[Bir Kişinin Yasağı Kaldırıldı]
$thumbnail[$userAvatar[$message[1]]]
$description[
Yasağı Kaldırılan Kişi : $username[$message[1]]
Yasağı Kaldıran Kişi : $username
]
$color[#ffffff]
$onlyIf[$isNumber[$message[1]]!=false;Girilen ıd değil]
$onlyIf[$message!=;Bir ıd girmelisin]
$onlyBotPerms[ban;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
$onlyPerms[ban;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
$suppressErrors[Bir hata ile karşılaşıldı]
`
})

bot.command({
  name: "kick",
  code:`
  $kick[$mentioned[1]]
  $thumbnail[$userAvatar[$mentioned[1]]]
  $title[Bir Üye Sunucudan Kicklendi]
  $description[
Kicklenen kişi : $username[$mentioned[1]]
Kickleyen kişi : $username
  ]
  $color[#ffffff]
  $onlyIf[$mentioned[1]!=$authorID;Kendini kickleyemezsin]
  $onlyPerms[kick;Bu komutu sadece **Atma** yetkisine sahip kişiler kullanabilir]
  $onlyBotPerms[kick;Botun **Atma** yetkisi yok]
  $argsCheck[>1;Birini etiketlemelisin]
  $suppressErrors[Kişi kicklenemiyor]
  `
})

bot.command({
  name: "ping",
  code:`
Bot Pingi = $botPing
Discord Pingi = $ping
  `
})

bot.command({
  name: "dc",
  aliases: ["çık"],
  code:`
  $leaveVC[$voiceID[$clientID]]
  $onlyIf[$voiceID[$clientID]!=;Zaten sesli kanalda değilim]
  $onlyIf[$voiceÏD!=;Bir sesli kanalda değilsin]
  $onlyForIDs[$getServerVar[şarkı];Bu komutu sadece müziği başlatan kullanabilie]
  `
})

bot.command({
  name: "otorol-bot",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirtmelisin]
  $onlyIf[message[1]!=;Ayarla veya sıfırla ile belirtmelisin]
  $if[$message[1]==ayarla]
  Botlara gelince artık rol vereceğim bilgilendirceğim kanal <#$mentionedChannels[1]>
  $setServerVar[book;$mentionedChannels[1]]
  $setServerVar[boor;$mentionedRoles[1]]
  $onlyIf[$mentionedChannels[1]!=;Bir kanal etiketlemelisin]
  $onlyIf[$mentionedRoles[1]!=;Bir rol etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Otorol Başarıyla Sıfırlandı
  $setServerVar[boor;]
  $setServerVar[book;]
  $onlyIf[$getServerVar[book]!=;Otorol zaten kapalı]
  $endif
  $onlyBotPerms[manageroles;Botun **Rolleri Yönet** yetkisi bulunmamakta]
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
  `
})

bot.joinCommand({
  channel: "$getServerVar[book]",
  code:`
  
  $author[Bir Bot Girdi Ve Rolünü Verdim]
  $description[<@$authorID> kişisine başarıyla <@&$getServerVar[boor]> rolünü verdim]
  $giveRole[$authorID;$getServerVar[boor]]
  $suppressErrors[Rol veremiyorum!!!]
$onlyIf[$isBot[$authorID]!=false;]
 $color[#ffffff] `
})



bot.command({
  name: "otorol",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirtmelisin]
  $onlyIf[$message!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  Otorol ayarlandı bir üye geldinde rolünü verip <#$mentionedChannels[1]>'e bildirceğim
  $setServerVar[orol;$mentionedRoles[1]]
  $setServerVar[otk;$mentionedChannels[1]]
  $onlyIf[$mentionedChannels[1]!=;Bir kanal etiketlemelisin]
  $onlyIf[$mentionedRoles[1]!=;Bir rol etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Otorol sıfırlandı
  $setServerVar[orol;]
  $setServerVar[otk;]
  $onlyIf[$getServerVar[orol]!=;Otorol zaten kapalı]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
  `
})

bot.joinCommand({
  channel: "$getServerVar[otk]",
  code:`
  $author[Bir Üye Girdi Ve Rolünü Verdim]
  $description[<@$authorID> kişisine başarıyla <@&$getServerVar[orol]> rolünü verdim]
  $giveRole[$authorID;$getServerVar[orol]]
$suppressErrors[Rol Veremiyorum!!!]
  $onlyIf[$isBot[$authorID]!=true;]
  $color[#ffffff]
  `
})

bot.joinCommand({
  channel: "$getServerVar[sayaçl]",
  code:`
\`$username\` sunucumuza katıldı onla beraber \`$membersCount\` kişiyiz  
  `
})

bot.leaveCommand({
  channel: "$getServerVar[sayaçl]",
  code:`
  \`$username\` sunucumuzdsan ayrıldı \`$membersCount\` kişiyiz
  `
})

bot.command({
  name: "$alwaysExecute",
  code:`
  Link atmamalısın <@$authorID>
  $deletecommand
  $deleteIn[5s]
  $onlyIf[$hasPerms[$authorID;admin]!=true;]
  $onlyIf[$checkContains[$toLowercase[$message];https;.com;http;.gg;discord.gg]==true;]
  $onlyIf[$getServerVar[lengel]!=kapalı;]
  `,
  nonPrefixed: true
})

bot.command({
  name: "çıkban",
  code:`
  $onlyIf[$checkContains[$message[1];aç;kapat]==true;Aç veya kapatla belirtmelisin]
  $onlyIf[$message[1]!=;Aç ve ya kapat yazmalısın]
  $if[$message[1]==aç]
  Çıkban açıldı
  $setServerVar[çban;açık]
  $onlyIf[$getServerVar[çban]!=açık;Çıkban zaten açık]
  $onlyBotPerms[ban;Botun **ban** yetkisi yok]
  $endif
  $if[$message[1]==kapat]
  Çıkban kapatıldı
  $setServerVar[çban;kapalı]
  $onlyIf[$getServerVar[çban]!=kapalı;Çıkban zaten kapalı]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
  `
})

bot.leaveCommand({
  channel: "$randomChannelID",
  code:`
  $ban[$authorID;Çıkban]
  $suppressErrors[]
  $onlyIf[$getServerVar[çban]!=kapalı;]
  `
})

bot.command({
  name: "anti-raid",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirtmelisin]
  $onlyIf[$message[1]!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  Anti raid kanalı <#$mentionedChannels[1]> olarak belirlendi
  $setServerVar[antib;$mentionedChannels[1]]
  $onlyIf[$mentionedChannels[1]!=;Bir kanal etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Anti raid sıfırlandı
  $setServerVar[antib;]
  $onlyIf[$getServerVar[antib]!=;Anti raid zaten ayarlanmamış]
  $endif
  $onlyBotPerms[ban;Botun **banlama** yetkisi yok]
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
  `
})

bot.joinCommand({
  channel: "$getServerVar[antib]",
  code:`
  \`$username\` sunucuya katıldı ancak bot olduğundan banlandı
  $ban[$authorID;Anti Raid]
  $onlyIf[$isBot[$authorID]!=false;]
  $suppressErrors[\`$username\` botu banlayamadım lütfen banlama yetkimin oldunu kontrol et]
  $onlyIf[$getServerVar[antib]!=;]
  `
})

bot.command({
  name: "pre-ver",
  code:`
  Premium $username[$mentioned[1]]'e verildi
  $setGlobalUserVar[premium;yes;$mentioned[1]]
  $onlyIf[$getGlobalUserVar[premium;$mentioned[1]]!=yes;Zaten bu kişinin premiumu var]
  $onlyIf[$mentioned[1]!=$clientID;Ben kendime premium mu vercem?]
  $argsCheck[>1;Birini etiketle]
  $onlyForIDs[$botOwnerID;]
 
  `
})

bot.command({
  name: "pre-al",
  code:`
  Premium $username[$mentioned[1]] den alındı
  $setGlobalUserVar[premium;no;$mentioned[1]]
  $onlyIf[$getGlobalUserVar[premium;$mentioned[1]]!=no;Zaten premiumu yok]
  $onlyIf[$mentioned[1]!=$clientID;$username[$botOwnerID] beni delirtmek mi istiyorsun]
  $argsCheck[>1;Birini etiketlemelisin]
  $onlyForIDs[$botOwnerID;]
  `
})

bot.command({
  name: "pre-kontrol",
  code:`
  $if[$message[1]!=$mentioned[1]]
  Presi $replaceText[$replaceText[$getGlobalUserVar[premium;$mentioned[1]];no;Bulunmamakta];yes;Bulunmakta]
  $else
  Pren $replaceText[$replaceText[$getGlobalUserVar[premium;$authorID];no;Bulunmamakta];yes;Bulunmakta]
  $endif
  `
})

bot.command({
  name: "mesaj-log",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirtmelisin]
  $onlyIf[$message[1]!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  Mesaj log <#$mentionedChannels[1]> olarak belirlendi
  $setServerVar[mesajlog;$mentionedChannels[1]]
  $onlyIf[$mentionedChannels[1]!=;Bir kanal etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Mesaj log sıfırlandı
  $setServerVar[mesajlog;]
  $onlyIf[$getServerVar[mesajlog]!=;Mesaj log zaten ayarlanmamış]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
  `
})

bot.command({
  name:"istek-log",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirtmelisin]
  $onlyIf[$message[1]!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  İstek log <#$mentionedChannels[1]> olarak ayarlandı
  $setServerVar[ilog;$mentionedChannels[1]]
  $onlyIf[$mentionedChannels[1]!=;Bir kanal etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  İstek log sıfırlandı
  $setServerVar[ilog;]
  $onlyIf[$getServerVar[ilog]!=;İstek log zaten kapalı]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
  `
})

bot.command({
  name: "istek",
  code:`
  $channelSendMessage[$getServerVar[ilog];
  {title:Yeni Bir İstek}
  {description:
İstek  \`$message\`  

İsteği Gönderen Kişi  \`<@$authorID> | $authorID | $username\`}
{color:RANDOM}
  ]
  İsteğiniz <#$getServerVar[ilog]> kanalına iletilmiştir <@$authorID>
  $deletecommand
  $deleteIn[4s]
  $onlyIf[$message!=;Bir istek metni belirtmelisin]
  $onlyIf[$getServerVar[ilog]!=;]
  `
})

bot.command({
  name: "bakım",
  code:`
  $onlyIf[$checkContains[$message[1];aç;kapat]==true;Aç veya kapat la belirtmelisin]
  $onlyIf[$message!=;Aç ve ya kapat yazmalısın]
  $if[$message[1]==aç]
  Bakım açıldı
  $setGlobalUserVar[bakım;açık]
  $onlyIf[$getGlobalUserVar[bakım;$authorID]!=açık;Bakım zaten açık]
  $endif
  $if[$message[1]==kapat]
  Bakım Kapatıldı
  $setGlobalUserVar[bakım;kapalı]
  $onlyIf[$getGlobalUserVar[bakım;$authorID]!=kapalı;Bakım zaten kapalı]
  $endif
  $onlyForIDs[$botOwnerID;]
  `
})

bot.command({
  name: "banlog",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirtmelisin]
  $onlyIf[$message!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  Ban log kanalı <#$mentionedChannels[1]> kanalı olarak ayarlandı
  $setServerVar[banl;$mentionedChannels[1]]
  $onlyIf[$mentionedChannels[1]!=;Bir kanal etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Ban log Kapatıld
  $setServerVar[banl;]
  $onlyIf[$getServerVar[banl]!=;Ban log zaten ayarlanmamış]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
  `
})

bot.banAddCommand({
  channel: "$getServerVar[banl]",
  code:`
  $title[Bir Kişi Sunucundan Banlandı]
  $description[
  Banlanan Kişi : $username
  ]
  $color[#ffffff]
  `
})

bot.banRemoveCommand({
  channel: "$getServerVar[banl]",
  code:`
  $title[Bir Ban Affı Gerçekleşdi]
  $description[
  Banı Kaldırılan Kişi : $username
  ]
  $color[#ffffff]
  `
})

bot.command({
   name: "$alwaysExecute",
   code:`
$addCmdReactions[🔶]

$onlyForChannels[$getServerVar[ekanal];]
$onlyIf[$getServerVar[ekanal]!=;]
`,
nonPrefixed: true
})

bot.command({
name:"tepki-kanal",
code:`$onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla veya sıfırla ile belirtmelisin]
$if[$message[1]==ayarla]
$setServerVar[ekanal;$mentionedChannels[1]]
Tepki kanal <#$mentionedChannels[1]> olarak ayarlandı
$endif
$if[$message[1]==sıfırla]
Tepki kanal sıfırlandı
$setServerVar[ekanal;]
$onlyIf[$getServerVar[ekanal]!=;Zaten kapalı]
$endif
$onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
`})

bot.command({
  name: "modlog",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla veya sıfırla ile belirtmelisin]
  $onlyIf[$message!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  Mod log <#$mentionedChannels[1]> olarak belirlendi
  $setServerVar[modlog;$mentionedChannels[1]]
  $onlyIf[$mentionedChannels[1]!=;Bir kanal etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Modlog sıfırlandı
  $setServerVar[modlog;]
  $onlyIf[$getServerVar[modlog]!=;Mod log zaten ayarlanmamış]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
  `
})

bot.roleCreateCommand({
  channel: "$getServerVar[modlog]",
  code:`
  $title[Bir Rol Oluşturuldu]
  $description[
  Rol ismi = \`$newRole[name]\`
  
 Rol ID = \`$newRole[id]\`
  
 Hex Rengi = \`$newRole[hexColor]\`
  
 Rengi =  \`$newRole[color]\`
  
 Rol Yetkileri = \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$rolePerms[$roleID[$newRole[name]];|];Administrator;Yönetici;-1];Manage Guild;Sunucuyu Yönet;-1];Kick Members;Üyeleri At;-1];Create Instant Invite;Davet Oluştur;-1];Ban Members;Üyeleri Yasakla;-1];Manage Channels;Kanalları Yönet;-1];Add Reactions;Tepki Ekle;-1];View Audit Log;Denetim Kaydını Görüntüle;-1];View Channel;Kanalları Görüntüle;-1];Send Messages;Mesaj Gönder;-1];Manage Messages;Mesajları Yönet;-1];Embed Links;Gömülü Bağlantı Yerleştir;-1];Attach Files;Dosya Ekle;-1];Read Message History;Mesaj Geçmişini Görüntüle;-1];Mention Everyone;Herkesten Bahset;-1];View Guild Insights;Sunucu İstatistiklerini Görüntüle;-1];Connect;Bağlan;-1];Speak;Konuş;-1];Mute Members;Üyeleri Sustur;-1];Deafen Members;Üyeleri Sağırlaştır;-1];Move Members;Üyeleri Taşı;-1];Manage Nicknames;Kullanıcı Adlarını Yönet;-1];Manage Roles;Rolleri Yönet;-1];Manage Webhooks;Webhook'ları Yönet;-1];Manage Emojis;Emojileri Yönet;-1]\`
  
 Etiket Atılabilir mi = \`$replaceText[$replaceText[$newRole[mentionable];false;Hayır;];true;Evet;]\`
  ]
$onlyIf[$getServerVar[modlog]!=;]
  $color[#ffffff]
  `
})


bot.roleDeleteCommand({
  channel: "$getServerVar[modlog]",
  code:`
  $title[Bir Rol Silindi]
  $description[
Rolün İsmi = $oldRole[name]  
  ]
  $color[RANDOM]
$onlyIf[$getServerVar[modlog]!=;]
  `
})

bot.roleUpdateCommand({
  channel: "$getServerVar[modlog]",
  code:`
  $title[Bir Rol Güncellendi]
  $description[
Eski Rol İsmi = \`$oldRole[name]\`
Eski Rol ID = \`$oldRole[id]\`
Eski Rol Hex Rengi = \`$oldRole[hexColor]\`
Eski Rol Rengi = \`$oldRole[color]\`
Eski Rol Yetkileri = \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$rolePerms[$roleID[$newRole[name]];|];Administrator;Yönetici;-1];Manage Guild;Sunucuyu Yönet;-1];Kick Members;Üyeleri At;-1];Create Instant Invite;Davet Oluştur;-1];Ban Members;Üyeleri Yasakla;-1];Manage Channels;Kanalları Yönet;-1];Add Reactions;Tepki Ekle;-1];View Audit Log;Denetim Kaydını Görüntüle;-1];View Channel;Kanalları Görüntüle;-1];Send Messages;Mesaj Gönder;-1];Manage Messages;Mesajları Yönet;-1];Embed Links;Gömülü Bağlantı Yerleştir;-1];Attach Files;Dosya Ekle;-1];Read Message History;Mesaj Geçmişini Görüntüle;-1];Mention Everyone;Herkesten Bahset;-1];View Guild Insights;Sunucu İstatistiklerini Görüntüle;-1];Connect;Bağlan;-1];Speak;Konuş;-1];Mute Members;Üyeleri Sustur;-1];Deafen Members;Üyeleri Sağırlaştır;-1];Move Members;Üyeleri Taşı;-1];Manage Nicknames;Kullanıcı Adlarını Yönet;-1];Manage Roles;Rolleri Yönet;-1];Manage Webhooks;Webhook'ları Yönet;-1];Manage Emojis;Emojileri Yönet;-1]

Eski Rol Etiketlene bilir mi = \`$replaceText[$replaceText[$oldRole[mentionable];false;Hayır];true;Evet]\`
------
Yeni Rol İsmi = \`$newRole[name]\`
Yeni Rol ID = \`$newRole[id]\`
Yeni Rol Hex Rengi = \`$newRole[hexColor]\`
Yeni Rol Rengi = \`$newRole[color]\`
Yeni Rol Yetkileri$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$rolePerms[$roleID[$newRole[name]];|];Administrator;Yönetici;-1];Manage Guild;Sunucuyu Yönet;-1];Kick Members;Üyeleri At;-1];Create Instant Invite;Davet Oluştur;-1];Ban Members;Üyeleri Yasakla;-1];Manage Channels;Kanalları Yönet;-1];Add Reactions;Tepki Ekle;-1];View Audit Log;Denetim Kaydını Görüntüle;-1];View Channel;Kanalları Görüntüle;-1];Send Messages;Mesaj Gönder;-1];Manage Messages;Mesajları Yönet;-1];Embed Links;Gömülü Bağlantı Yerleştir;-1];Attach Files;Dosya Ekle;-1];Read Message History;Mesaj Geçmişini Görüntüle;-1];Mention Everyone;Herkesten Bahset;-1];View Guild Insights;Sunucu İstatistiklerini Görüntüle;-1];Connect;Bağlan;-1];Speak;Konuş;-1];Mute Members;Üyeleri Sustur;-1];Deafen Members;Üyeleri Sağırlaştır;-1];Move Members;Üyeleri Taşı;-1];Manage Nicknames;Kullanıcı Adlarını Yönet;-1];Manage Roles;Rolleri Yönet;-1];Manage Webhooks;Webhook'ları Yönet;-1];Manage Emojis;Emojileri Yönet;-1]\`
Yeni Rol Etiketlene bilir mi = \`$replaceText[$replaceText[$newRole[mentionable];false;Hayır];true;Evet]\`
  ]
$onlyIf[$getServerVar[modlog]!=;]
  $color[#ffffff]
  `
})

bot.channelCreateCommand({
  channel: "$getServerVar[modlog]",
  code:`
  $title[Bir Kanal Oluşturuldu]
  $description[
Kanal İsmi = \`$newChannel[name]\`

Kanal ID = \`$newChannel[id]\`

Kanal Pozisyonu = \`$newChannel[position]\`

Kanal Kategori IDsi = \`$newChannel[categoryID]\`
  
Kanal Nsfw = \`$replaceText[$replaceText[$newChannel[nsfw];false;Hayır];true;Evet]\`

Kanal Yavaş Modu = \`$replaceText[$newChannel[slowmode];0;Yok]\`
  ]
$onlyIf[$getServerVar[modlog]!=;]
  $color[RANDOM]
  `
})

bot.channelDeleteCommand({
  channel: "$getServerVar[modlog]",
  code:`
  $title[Bir Kanal Silindi]
  $description[
Silinen Kanal İsmi = $oldChannel[name]  
  ]
  $color[#ffffff]
$onlyIf[$getServerVar[modlog]!=;]
  `
}) 

bot.channelUpdateCommand({
  channel: "$getServerVar[modlog]",
  code:`
  $title[Bir Kanal Güncellendi]
  $description[
Eski Kanal İsmi = \`$oldChannel[name]\`

Eski Kanal ID = \`$oldChannel[id]\`

Eski Kanal Pozisyonu = \`$oldChannel[position]\`

Eski Kanal Nsfw = \`$replaceText[$replaceText[$oldChannel[nsfw];true;Evet];false;Hayır]\`

Eski Kanal Yavaş Mod = \`$replaceText[$oldChannel[slowmode];0;Yok]\`
------
Yeni Kanal İsmi = \`$newChannel[name]\`

Yeni Kanal ID = \`$newChannel[id]\`

Yeni Kanal Pozisyonu =  \`$newChannel[position]\`

Yeni Kanal Kategori IDsi = \`$newChannel[categoryID]\`
  
Yeni Kanal Nsfw = \`$replaceText[$replaceText[$newChannel[nsfw];false;Hayır];true;Evet]\`

Yeni Kanal Yavaş Modu = \`$replaceText[$newChannel[slowmode];0;Yok]\`
  ]
  $onlyIf[$getServerVar[modlog]!=;]
  $color[RANDOM]
  
  `
})

bot.inviteCreateCommand({
  channel: "$getServerVar[modlog]",
  code:`
  $title[Bir Davet Oluşturuldu]
  $description[
Daveti Açan = <@$inviteUserID>

Davet Linki = \`$inviteUrl\`

Davet Edilen Kanal = <#$inviteChannelID>




  ]
  $color[#ffffff]
$onlyIf[$getServerVar[modlog]!=;]
  `
})

bot.inviteDeleteCommand({
  channel: "$getServerVar[modlog]",
  code:`
  $title[Bir Davet Silindi]
  $description[
Davet Linki = \`$inviteUrl\`

Davet Edilen Kalan = <#$inviteChannelID>
  ]
  $color[RANDOM]
$onlyIf[$getServerVar[modlog]!=;]
  `
})

bot.command({
  name: "küfürengel",
  code:`
  $onlyIf[$checkContains[$message;aç;kapat]==true;Aç veya kapat yazmalısın]
  $onlyIf[$message!=;Aç ve ya kapat yazmalısın]
  $if[$message==aç]
  Küfür engel açıldı
  $setServerVar[kengel;açık]
  $onlyIf[$getServerVar[kengel]!=açık;Küfür engel zaten açık]
  $endif
  $if[$message==kapat]
  Küfür engel kapatıldı
  $setServerVar[kengel;kapalı]
  $onlyIf[$getServerVar[kengel]!=kapalı;Küfür engel zaten kapalı]
  $endif
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
  `
})

bot.command({
  name: "$alwaysExecute",
  code:`
  Yasaklı Kelime Kullanma <@$authorID>
  $deleteIn[5s]
  $deletecommand
  $onlyIf[$hasPerms[$authorID;admin]!=true;]
  $onlyIf[$checkContains[$toLowercase[$message];aq;amk;orospu;sikik;sg]==true;]
  $onlyIf[$getServerVar[kengel]!=kapalı;]
  `,
  nonPrefixed: true
})

bot.command({
  name: "tag",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirtmelisin]
  $onlyIf[$message!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  Tag \`$message[2]\` olarak ayarlandı
  $setServerVar[ktag;$message[2]]
  $onlyIf[$message[2]!=;Bir tag yazmalısın]
  $endif
  $if[$message[1]==sıfırla]
  Tag sıfırlandı
  $setServerVar[ktag;]
  $onlyIf[$getServerVar[ktag]!=;Zaten ayarlanmamış]
  $endif
  $onlyPerms[admin;Bu komutu sadecew **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
$onlyIf[$getServerVar[kayıt]!=kapalı;]

  `
})

bot.command({
  name: "vrol",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirtmelisin]
  $onlyIf[$message!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  Verilcek rol $mentionedRoles[1] ID li rol olarak belirlendi
  $setServerVar[vrol;$mentionedRoles[1]]
  $onlyIf[$mentionedRoles[1]!=;Bir rol etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Verilcek rol sıfırlandı
  $setServerVar[vrol;]
  $onlyIf[$getServerVar[vrol]!=;Zaten ayarlanmamış]
  $endif
  $onlyBotPerms[manageroles;Botun **Rolleri Yönet** yetkisine sahip değil]
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
$onlyIf[$getServerVar[kayıt]!=kapalı;]
  `
})

bot.command({
  name: "arol",
  code:`
  $onlyIf[$checkContains[$message[1];ayarla;sıfırla]==true;Ayarla ve ya sıfırla ile belirtmelisin]
  $onlyIf[$message!=;Ayarla ve ya sıfırla yazmalısın]
  $if[$message[1]==ayarla]
  Alıncak rol $mentionedRoles[1] ID li rol olarak ayarlandı
  $setServerVar[arol;$mentionedRoles[1]]
  $onlyIf[$mentionedRoles[1]!=;Bir rol etiketlemelisin]
  $endif
  $if[$message[1]==sıfırla]
  Alıncak rol sıfırlandı
  $setServerVar[arol;]
  $onlyIf[$getServerVar[arol]!=;Zaten ayarlanmamış]
  $endif
  $onlyBotPerms[manageroles;Botun **Rolleri Yönet** yetkisi bulunmamakta]
  $onlyPerms[admin;Bu komutu sadece **Yönetici** yetkisine sahip kişiler kullanabilir]
  $onlyIf[$getGlobalUserVar[bakım;$botOwnerID]!=açık;Bakım modu açık]
$onlyIf[$getServerVar[kayıt]!=kapalı;]
  `
})


//komutları üste yazın
//durum
bot.status({
  text: "Allegro Entwicklung",//durum yazısı
  type: "PLAYING", //oynuyor kısmı
  status: "dnd", //presence
  time: 12 //burayı elleme
})
bot.status({
  text: "", //durum yazısı
  type: "PLAYING", //oynuyor kısmı
  status: "dnd", //presence
  time: 12 //burayı elleme
})
bot.status({
  text: "", //durum yazısı
  type: "PLAYING", //oynuyor kısmı
  status: "dnd", //presence
  time: 12 //burayı elleme
})
//variablelar
bot.variables({
  para: "0",
  banka: "0",
  şarkı: "",
  boor: "",
  book: "",
  otk: "",
  orol: "",
  sayaçl: "",
  lengel: "kapalı",
  çban: "kapalı",
  antib: "",
  lvl: "0",
  sınır: "200",
  xp: "0",
  meslek: "boşta",
  premium: "no",
  mesajlog: "",
  levela: "açık",
  ilog: "",
  bakım: "kapalı",
  banl: "",
  möğretim: "öğrenmemiş",
  töğretim: "öğrenmemiş",
  ekanal: "",
  modlog: "",
  kengel: "kapalı",
  aboner: "",
  vrol: "",
  arol: "",
  kkanal: "",
  ktag: "",
  klog: "",
  kayıt: "kapalı",
  hgbb: "",
  afk: "no",
  afks: "",
  msje: "",
  yardımcı: "",
  rsayı: "0",
  gururlu: "",
  skanal: "",
  ssayı: "0",
  stsayı: "",
  stkanal: "",
  uyarıs: "0",
  uyarmas: "0",
  uyarıa: "kapalı",
  mrol: "",
  mlog: ""
})